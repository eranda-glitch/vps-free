$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$files = Get-ChildItem -LiteralPath (Join-Path $root 'src/app/Husk') -Recurse -Filter '*.swift'
$stringPattern = '"(?<text>(?:\\.|[^"\\])*)"'
$preserve = @(
    'Leviidev/Husk',
    'HuskSourceURLs',
    'HuskBuildCommit',
    'HuskBuildDate',
    'HuskJITHelper.appex',
    'HuskBuiltInJIT',
    'HuskJIT'
)

foreach ($file in $files) {
    $source = [IO.File]::ReadAllText($file.FullName)
    $updated = [regex]::Replace($source, $stringPattern, {
        param($match)
        $text = $match.Groups['text'].Value
        if (-not $text.Contains('Husk')) { return $match.Value }
        foreach ($token in $preserve) {
            if ($text.Contains($token)) { return $match.Value }
        }
        return $match.Value.Replace('Husk', 'Senumy')
    })
    if ($updated -ne $source) {
        [IO.File]::WriteAllText($file.FullName, $updated, [Text.UTF8Encoding]::new($false))
    }
}
