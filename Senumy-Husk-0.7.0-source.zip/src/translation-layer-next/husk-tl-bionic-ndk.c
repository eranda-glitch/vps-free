/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * The NDK's own libraries: libandroid (looper, assets, windows, sensors), libmediandk,
 * and zlib. EGL and GLES are in husk-tl-egl.c.
 */
#define _DARWIN_C_SOURCE
#include "husk-tl-bionic.h"

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include <zlib.h>

#include "husk-tl-internal.h"
#include "husk-tl-ld.h"

/* ---------------------------------------------------------------- looper */

/*
 * Android's ALooper is a per-thread event loop that other threads wake with a write
 * to a pipe. Unity's main thread polls it between frames. This one has the wake pipe
 * and nothing else registered on it: no file descriptors, no callbacks.
 */
typedef struct looper_fd { int fd, ident, events; void *callback, *data; struct looper_fd *next; } looper_fd;
typedef struct tl_looper { int wake[2]; atomic_int refs; pthread_t thread; struct tl_looper *next; pthread_mutex_t mu; looper_fd *fds; } tl_looper;
static __thread tl_looper *t_looper;

enum { ALOOPER_POLL_WAKE = -1, ALOOPER_POLL_CALLBACK = -2, ALOOPER_POLL_TIMEOUT = -3, ALOOPER_POLL_ERROR = -4 };
enum { ALOOPER_EVENT_INPUT = 1, ALOOPER_EVENT_OUTPUT = 2, ALOOPER_EVENT_ERROR = 4, ALOOPER_EVENT_HANGUP = 8 };

static tl_looper *looper_make(void)
{
    tl_looper *l = calloc(1, sizeof(*l));
    if (pipe(l->wake) == 0) {
        fcntl(l->wake[0], F_SETFL, O_NONBLOCK);
        fcntl(l->wake[1], F_SETFL, O_NONBLOCK);
    }
    atomic_init(&l->refs, 1);
    pthread_mutex_init(&l->mu, NULL);
    l->thread = pthread_self();
    return l;
}
static void *b_ALooper_prepare(int opts) { (void)opts; if (!t_looper) t_looper = looper_make(); return t_looper; }
static void *b_ALooper_forThread(void) { return t_looper; }
static void b_ALooper_acquire(tl_looper *l) { if (l) atomic_fetch_add(&l->refs, 1); }
static void b_ALooper_release(tl_looper *l) { (void)l; }
static void b_ALooper_wake(tl_looper *l)
{
    if (!l) return;
    char c = 1;
    (void)!write(l->wake[1], &c, 1);
}

/* A file descriptor the looper watches: with a callback it is called from the polling thread; without one, its ident is returned. */
static int b_ALooper_addFd(tl_looper *l, int fd, int ident, int events, void *callback, void *data)
{
    if (!l || fd < 0) return -1;
    pthread_mutex_lock(&l->mu);
    looper_fd *f = l->fds;
    while (f && f->fd != fd) f = f->next;
    if (!f) { f = calloc(1, sizeof(*f)); f->next = l->fds; l->fds = f; }
    f->fd = fd; f->ident = ident; f->events = events; f->callback = callback; f->data = data;
    pthread_mutex_unlock(&l->mu);
    b_ALooper_wake(l);
    return 1;
}
static int b_ALooper_removeFd(tl_looper *l, int fd)
{
    if (!l) return -1;
    int found = 0;
    pthread_mutex_lock(&l->mu);
    for (looper_fd **pp = &l->fds; *pp; pp = &(*pp)->next)
        if ((*pp)->fd == fd) { looper_fd *dead = *pp; *pp = dead->next; free(dead); found = 1; break; }
    pthread_mutex_unlock(&l->mu);
    return found;
}

static int b_ALooper_pollOnce(int timeout_ms, int *out_fd, int *out_events, void **out_data)
{
    tl_looper *l = t_looper;
    if (out_fd) *out_fd = -1;
    if (out_events) *out_events = 0;
    if (out_data) *out_data = NULL;
    if (!l) return ALOOPER_POLL_ERROR;
    struct pollfd pfds[32];
    looper_fd snap[31];
    int n = 0;
    pfds[n++] = (struct pollfd){ l->wake[0], POLLIN, 0 };
    pthread_mutex_lock(&l->mu);
    for (looper_fd *f = l->fds; f && n < 32; f = f->next) {
        short ev = (short)(((f->events & ALOOPER_EVENT_INPUT) ? POLLIN : 0) | ((f->events & ALOOPER_EVENT_OUTPUT) ? POLLOUT : 0));
        snap[n - 1] = *f;
        pfds[n++] = (struct pollfd){ f->fd, ev, 0 };
    }
    pthread_mutex_unlock(&l->mu);
    int r = poll(pfds, (nfds_t)n, timeout_ms);
    if (r < 0) return ALOOPER_POLL_ERROR;
    if (r == 0) return ALOOPER_POLL_TIMEOUT;
    if (pfds[0].revents & POLLIN) { char buf[64]; while (read(l->wake[0], buf, sizeof(buf)) > 0) {} }
    for (int i = 1; i < n; i++) {
        if (!pfds[i].revents) continue;
        looper_fd *f = &snap[i - 1];
        int ev = ((pfds[i].revents & POLLIN) ? ALOOPER_EVENT_INPUT : 0) | ((pfds[i].revents & POLLOUT) ? ALOOPER_EVENT_OUTPUT : 0)
               | ((pfds[i].revents & POLLERR) ? ALOOPER_EVENT_ERROR : 0) | ((pfds[i].revents & POLLHUP) ? ALOOPER_EVENT_HANGUP : 0);
        if (f->callback) {
            int keep = ((int (*)(int, int, void *))f->callback)(f->fd, ev, f->data);
            if (!keep) b_ALooper_removeFd(l, f->fd);
            return ALOOPER_POLL_CALLBACK;
        }
        if (out_fd) *out_fd = f->fd;
        if (out_events) *out_events = ev;
        if (out_data) *out_data = f->data;
        return f->ident;
    }
    return ALOOPER_POLL_WAKE;
}
static int b_ALooper_pollAll(int timeout_ms, int *out_fd, int *out_events, void **out_data)
{
    for (;;) {
        int r = b_ALooper_pollOnce(timeout_ms, out_fd, out_events, out_data);
        if (r != ALOOPER_POLL_CALLBACK) return r;
        timeout_ms = 0;
    }
}

/* ----------------------------------------------------------- configuration */

/* AConfiguration: an English, landscape, phone-sized device. */
typedef struct { char language[2], country[2]; int orientation, density, screen_long, screen_size, ui_mode_type, ui_mode_night; } tl_aconfig;
static tl_aconfig *b_AConfiguration_new(void)
{
    tl_aconfig *c = calloc(1, sizeof(*c));
    memcpy(c->language, "en", 2); memcpy(c->country, "US", 2);
    c->orientation = 2; c->density = 480; c->screen_long = 2; c->screen_size = 2;
    return c;
}
static void b_AConfiguration_delete(tl_aconfig *c) { free(c); }
static void b_AConfiguration_fromAssetManager(tl_aconfig *c, void *mgr) { (void)c; (void)mgr; }
static void b_AConfiguration_getLanguage(tl_aconfig *c, char *out) { out[0] = c->language[0]; out[1] = c->language[1]; }
static void b_AConfiguration_getCountry(tl_aconfig *c, char *out) { out[0] = c->country[0]; out[1] = c->country[1]; }
static int b_AConfiguration_getOrientation(tl_aconfig *c) { return c->orientation; }
static int b_AConfiguration_getDensity(tl_aconfig *c) { return c->density; }
static int b_AConfiguration_getScreenLong(tl_aconfig *c) { return c->screen_long; }
static int b_AConfiguration_getScreenSize(tl_aconfig *c) { return c->screen_size; }
static int b_AConfiguration_getUiModeType(tl_aconfig *c) { return c->ui_mode_type; }
static int b_AConfiguration_getUiModeNight(tl_aconfig *c) { return c->ui_mode_night; }
static int b_AConfiguration_getKeyboard(tl_aconfig *c) { (void)c; return 1; }
static int b_AConfiguration_getNavigation(tl_aconfig *c) { (void)c; return 1; }
static int b_AConfiguration_getTouchscreen(tl_aconfig *c) { (void)c; return 3; }
static int b_AConfiguration_getSdkVersion(tl_aconfig *c) { (void)c; return 34; }

/* ---------------------------------------------------------------- assets */

typedef struct { const uint8_t *data; size_t len; size_t pos; uint8_t *owned; } tl_asset;

static void *b_AAssetManager_fromJava(void *env, void *obj) { (void)env; (void)obj; static int mgr; return &mgr; }

static void *b_AAssetManager_open(void *mgr, const char *name, int mode)
{
    (void)mgr; (void)mode;
    char path[1024];
    snprintf(path, sizeof(path), "assets/%s", name);
    static int trace = -1;
    if (trace < 0) trace = getenv("TL_FILE_TRACE") != NULL;
    if (trace) tl_log_line("assets: open %s", name);
    /* TL_ASSET_DIR: a file of that name under this directory stands in for the one in the APK (to change a game's config while debugging) */
    if (getenv("TL_ASSET_DIR")) {
        char alt[1100];
        snprintf(alt, sizeof(alt), "%s/%s", getenv("TL_ASSET_DIR"), name);
        FILE *fp = fopen(alt, "rb");
        if (fp) {
            fseek(fp, 0, SEEK_END); long n = ftell(fp); fseek(fp, 0, SEEK_SET);
            uint8_t *buf = malloc((size_t)n + 1);
            if (buf && fread(buf, 1, (size_t)n, fp) == (size_t)n) {
                fclose(fp);
                tl_asset *a = calloc(1, sizeof(*a));
                a->data = buf; a->len = (size_t)n; a->owned = buf;
                return a;
            }
            free(buf); fclose(fp);
        }
    }
    for (int i = 0;; i++) {
        const tl_zip *z = tl_ld_apk_at(i);
        if (!z) break;
        const tl_zip_entry *e = tl_zip_find(z, path);
        if (!e) continue;
        const uint8_t *data; size_t n; bool owned; char err[160];
        if (!tl_zip_data(z, e, (size_t)2 << 30, &data, &n, &owned, err, sizeof(err))) {
            tl_log_line("assets: %s: %s", name, err);
            return NULL;
        }
        tl_asset *a = calloc(1, sizeof(*a));
        a->data = data; a->len = n;
        if (owned) a->owned = (uint8_t *)data;
        return a;
    }
    return NULL;
}
/*
 * AAudio, the way FMOD (Minecraft's audio) prefers to play: a stream whose data callback the system calls for the next burst of
 * samples. The output is always 48 kHz stereo 16-bit; a thread of ours calls the game's callback for a burst and hands the result
 * to the host audio (tl_cocos_audio_hook, which blocks until the speakers have room -- that is what paces the game's mixer).
 * Recording is not offered.
 */
extern void (*tl_cocos_audio_hook)(const int16_t *samples, int frames, int channels, int rate);

enum { AA_OK = 0, AA_UNAVAILABLE = -899, AA_FORMAT_I16 = 1, AA_STATE_OPEN = 2, AA_STATE_STARTED = 4, AA_STATE_STOPPED = 10, AA_STATE_CLOSED = 12 };
#define AA_RATE 48000
#define AA_CHANNELS 2
#define AA_BURST 1024

typedef int (*aa_data_cb)(void *stream, void *user, void *data, int frames);
typedef struct aa_builder { aa_data_cb cb; void *user; int direction; } aa_builder;
typedef struct aa_stream {
    aa_data_cb cb; void *user;
    atomic_int state, buffer_size;
    atomic_bool run;
    pthread_t thread;
    bool thread_started;
} aa_stream;

static int b_AAudio_createStreamBuilder(void **builder) { aa_builder *b = calloc(1, sizeof(*b)); *builder = b; return b ? AA_OK : AA_UNAVAILABLE; }
static int b_AAudioStreamBuilder_delete(aa_builder *b) { free(b); return AA_OK; }
static void b_AAudioStreamBuilder_setDataCallback(aa_builder *b, aa_data_cb cb, void *user) { b->cb = cb; b->user = user; }
static void b_AAudioStreamBuilder_setDirection(aa_builder *b, int d) { b->direction = d; }
static void b_AAudioStreamBuilder_ignore(aa_builder *b, int v) { (void)b; (void)v; }
static void b_AAudioStreamBuilder_setErrorCallback(aa_builder *b, void *cb, void *user) { (void)b; (void)cb; (void)user; }

static int b_AAudioStreamBuilder_openStream(aa_builder *b, aa_stream **out)
{
    if (b->direction != 0 || !b->cb) return AA_UNAVAILABLE;           /* output with a data callback only */
    aa_stream *s = calloc(1, sizeof(*s));
    s->cb = b->cb; s->user = b->user;
    atomic_store(&s->state, AA_STATE_OPEN); atomic_store(&s->buffer_size, AA_BURST * 2);
    *out = s;
    tl_log_line("aaudio: stream opened (%d Hz, %d channels, burst %d)", AA_RATE, AA_CHANNELS, AA_BURST);
    return AA_OK;
}

static void *aa_pump(void *arg)
{
    aa_stream *s = arg;
    pthread_setname_np("aaudio-pump");
    int16_t *buf = malloc((size_t)AA_BURST * AA_CHANNELS * sizeof(int16_t));
    while (atomic_load(&s->run)) {
        memset(buf, 0, (size_t)AA_BURST * AA_CHANNELS * sizeof(int16_t));
        int r = s->cb(s, s->user, buf, AA_BURST);
        if (!atomic_load(&s->run)) break;
        { static bool said; if (!said) { for (int i = 0; i < AA_BURST * AA_CHANNELS; i++) if (buf[i]) { said = true; tl_log_line("aaudio: the game's first non-silent burst (sample %d = %d)", i, buf[i]); break; } } }
        if (tl_cocos_audio_hook) tl_cocos_audio_hook(buf, AA_BURST, AA_CHANNELS, AA_RATE);
        else { struct timespec ts = { 0, (long)((double)AA_BURST * 1e9 / AA_RATE) }; nanosleep(&ts, NULL); }
        if (r != 0) break;
    }
    free(buf);
    return NULL;
}

static int b_AAudioStream_requestStart(aa_stream *s)
{
    if (atomic_exchange(&s->run, true)) return AA_OK;
    atomic_store(&s->state, AA_STATE_STARTED);
    pthread_attr_t a; pthread_attr_init(&a); pthread_attr_setstacksize(&a, 1u << 20);
    s->thread_started = pthread_create(&s->thread, &a, aa_pump, s) == 0;
    pthread_attr_destroy(&a);
    return AA_OK;
}
static int aa_stop(aa_stream *s, int state)
{
    if (atomic_exchange(&s->run, false) && s->thread_started) { pthread_join(s->thread, NULL); s->thread_started = false; }
    atomic_store(&s->state, state);
    return AA_OK;
}
static int b_AAudioStream_requestStop(aa_stream *s) { return aa_stop(s, AA_STATE_STOPPED); }
static int b_AAudioStream_close(aa_stream *s) { aa_stop(s, AA_STATE_CLOSED); free(s); return AA_OK; }
static int b_AAudioStream_getSampleRate(aa_stream *s) { (void)s; return AA_RATE; }
static int b_AAudioStream_getChannelCount(aa_stream *s) { (void)s; return AA_CHANNELS; }
static int b_AAudioStream_getFormat(aa_stream *s) { (void)s; return AA_FORMAT_I16; }
static int b_AAudioStream_getDeviceId(aa_stream *s) { (void)s; return 0; }
static int b_AAudioStream_getFramesPerBurst(aa_stream *s) { (void)s; return AA_BURST; }
static int b_AAudioStream_getBufferCapacityInFrames(aa_stream *s) { (void)s; return AA_BURST * 8; }
static int b_AAudioStream_getBufferSizeInFrames(aa_stream *s) { return atomic_load(&s->buffer_size); }
static int b_AAudioStream_setBufferSizeInFrames(aa_stream *s, int n) { atomic_store(&s->buffer_size, n); return n; }
static int b_AAudioStream_getXRunCount(aa_stream *s) { (void)s; return 0; }
static int b_AAudioStream_getState(aa_stream *s) { return atomic_load(&s->state); }
static int b_AAudioStream_read(aa_stream *s, void *buf, int frames, long timeout) { (void)s; (void)buf; (void)frames; (void)timeout; return AA_UNAVAILABLE; }
static const char *b_AAudio_convertResultToText(int r) { (void)r; return "AAudio is not available"; }

/* AAssetDir: the files directly under an asset directory, across the APKs */
typedef struct { char **names; size_t n, pos; } tl_assetdir;
static void *b_AAssetManager_openDir(void *mgr, const char *dir)
{
    (void)mgr;
    if (getenv("TL_FILE_TRACE")) tl_log_line("assets: openDir %s", dir);
    char prefix[1024];
    size_t pl = (size_t)snprintf(prefix, sizeof(prefix), "assets/%s%s", dir, dir[0] && dir[strlen(dir) - 1] != '/' ? "/" : "");
    tl_assetdir *d = calloc(1, sizeof(*d));
    size_t cap = 0;
    for (int i = 0;; i++) {
        const tl_zip *z = tl_ld_apk_at(i);
        if (!z) break;
        for (size_t k = 0; k < z->count; k++) {
            const char *name = z->entries[k].name;
            if (strncmp(name, prefix, pl) != 0 || !name[pl] || strchr(name + pl, '/')) continue;
            if (d->n == cap) { cap = cap ? cap * 2 : 64; d->names = realloc(d->names, cap * sizeof(char *)); }
            d->names[d->n++] = strdup(name + pl);
        }
    }
    return d;
}
static const char *b_AAssetDir_getNextFileName(tl_assetdir *d) { return d && d->pos < d->n ? d->names[d->pos++] : NULL; }
static void b_AAssetDir_close(tl_assetdir *d) { if (!d) return; for (size_t i = 0; i < d->n; i++) free(d->names[i]); free(d->names); free(d); }
static unsigned long b_deflateBound(void *strm, unsigned long n) { (void)strm; return n + (n >> 12) + (n >> 14) + (n >> 25) + 13; }

static void b_AAsset_close(tl_asset *a) { if (a) { free(a->owned); free(a); } }
static int b_AAsset_read(tl_asset *a, void *buf, size_t n)
{
    size_t left = a->len - a->pos;
    if (n > left) n = left;
    memcpy(buf, a->data + a->pos, n);
    a->pos += n;
    return (int)n;
}
static long b_AAsset_getLength(tl_asset *a) { return (long)a->len; }
static long b_AAsset_getRemainingLength(tl_asset *a) { return (long)(a->len - a->pos); }
static const void *b_AAsset_getBuffer(tl_asset *a) { return a->data; }
static long b_AAsset_seek(tl_asset *a, long off, int whence)
{
    long base = whence == 0 ? 0 : whence == 1 ? (long)a->pos : (long)a->len;
    long np = base + off;
    if (np < 0 || (size_t)np > a->len) return -1;
    a->pos = (size_t)np;
    return np;
}
static int b_AAsset_isAllocated(tl_asset *a) { return a->owned != NULL; }

/* ---------------------------------------------------------------- windows */

/* The input queue a NativeActivity's glue attaches to its looper. Nothing arrives through it here: touches and controllers are delivered by other means. */
static void b_AInputQueue_attachLooper(void *q, void *looper, int ident, void *cb, void *data) { (void)q; (void)looper; (void)ident; (void)cb; (void)data; }
static void b_AInputQueue_detachLooper(void *q) { (void)q; }
static int32_t b_AInputQueue_hasEvents(void *q) { (void)q; return 0; }
static int32_t b_AInputQueue_getEvent(void *q, void **ev) { (void)q; if (ev) *ev = NULL; return -1; }
static int32_t b_AInputQueue_preDispatchEvent(void *q, void *ev) { (void)q; (void)ev; return 0; }
static void b_AInputQueue_finishEvent(void *q, void *ev, int handled) { (void)q; (void)ev; (void)handled; }
static void b_ANativeActivity_noop(void *a) { (void)a; }
static void b_ANativeActivity_flags(void *a, uint32_t add, uint32_t remove) { (void)a; (void)add; (void)remove; }
static void b_ANativeActivity_input(void *a, uint32_t flags) { (void)a; (void)flags; }


typedef struct tl_nwindow { atomic_int refs; int width, height, format; void *layer; } tl_nwindow;
static tl_nwindow g_window = { 1, 1080, 2400, 1, NULL };

void tl_nwindow_configure(int w, int h, void *layer) { g_window.width = w; g_window.height = h; g_window.layer = layer; }
void *tl_nwindow_get(void) { atomic_fetch_add(&g_window.refs, 1); return &g_window; }
void *tl_nwindow_native(void *window) { return window ? ((tl_nwindow *)window)->layer : NULL; }
int tl_nwindow_width(void *window) { return window ? ((tl_nwindow *)window)->width : 0; }
int tl_nwindow_height(void *window) { return window ? ((tl_nwindow *)window)->height : 0; }

static void *b_ANativeWindow_fromSurface(void *env, void *surface) { (void)env; (void)surface; atomic_fetch_add(&g_window.refs, 1); return &g_window; }
static void b_ANativeWindow_acquire(tl_nwindow *w) { if (w) atomic_fetch_add(&w->refs, 1); }
static void b_ANativeWindow_release(tl_nwindow *w) { if (w) atomic_fetch_sub(&w->refs, 1); }
static int b_ANativeWindow_getWidth(tl_nwindow *w) { return w ? w->width : 0; }
static int b_ANativeWindow_getHeight(tl_nwindow *w) { return w ? w->height : 0; }
static int b_ANativeWindow_getFormat(tl_nwindow *w) { return w ? w->format : 0; }
static int b_ANativeWindow_setBuffersGeometry(tl_nwindow *w, int width, int height, int format)
{
    (void)width; (void)height; (void)format; (void)w;
    return 0;
}
static void *b_ANativeWindow_toSurface(void *env, void *w) { (void)env; (void)w; return NULL; }

/* ---------------------------------------------------------------- sensors */

static void *b_ASensorManager_getInstance(void) { static int m; return &m; }
static void *b_ASensorManager_getDefaultSensor(void *m, int type) { (void)m; (void)type; return NULL; }
static int b_ASensorManager_getSensorList(void *m, const void ***list) { (void)m; if (list) *list = NULL; return 0; }
static void *b_ASensorManager_createEventQueue(void *m, void *looper, int ident, void *cb, void *data)
{
    (void)m; (void)looper; (void)ident; (void)cb; (void)data;
    static int q; return &q;
}
static int b_ASensorManager_destroyEventQueue(void *m, void *q) { (void)m; (void)q; return 0; }
static int b_ASensorEventQueue_enableSensor(void *q, void *s) { (void)q; (void)s; return -1; }
static int b_ASensorEventQueue_disableSensor(void *q, void *s) { (void)q; (void)s; return -1; }
static int b_ASensorEventQueue_setEventRate(void *q, void *s, int us) { (void)q; (void)s; (void)us; return -1; }
static int b_ASensorEventQueue_hasEvents(void *q) { (void)q; return 0; }
static long b_ASensorEventQueue_getEvents(void *q, void *ev, size_t n) { (void)q; (void)ev; (void)n; return 0; }
static const char *b_ASensor_getName(void *s) { (void)s; return ""; }
static const char *b_ASensor_getVendor(void *s) { (void)s; return ""; }
static int b_ASensor_getType(void *s) { (void)s; return 0; }
static float b_ASensor_getResolution(void *s) { (void)s; return 0.f; }
static int b_ASensor_getMinDelay(void *s) { (void)s; return 0; }

/* ------------------------------------------------------------ media (none) */

#define MEDIA_ERR (-10000)
static void *b_media_null(void) { tl_note_once("libmediandk: media decoding is not provided (returning NULL)"); return NULL; }
static int b_media_err(void) { return MEDIA_ERR; }
static int b_media_zero(void) { return 0; }

#define KEY(sym, text) static const char *g_##sym = text;
KEY(AMEDIAFORMAT_KEY_CHANNEL_COUNT, "channel-count") KEY(AMEDIAFORMAT_KEY_COLOR_FORMAT, "color-format")
KEY(AMEDIAFORMAT_KEY_COLOR_RANGE, "color-range") KEY(AMEDIAFORMAT_KEY_COLOR_STANDARD, "color-standard")
KEY(AMEDIAFORMAT_KEY_DURATION, "durationUs") KEY(AMEDIAFORMAT_KEY_ENCODER_DELAY, "encoder-delay")
KEY(AMEDIAFORMAT_KEY_FRAME_RATE, "frame-rate") KEY(AMEDIAFORMAT_KEY_HEIGHT, "height")
KEY(AMEDIAFORMAT_KEY_LANGUAGE, "language") KEY(AMEDIAFORMAT_KEY_MIME, "mime")
KEY(AMEDIAFORMAT_KEY_ROTATION, "rotation-degrees") KEY(AMEDIAFORMAT_KEY_SAMPLE_RATE, "sample-rate")
KEY(AMEDIAFORMAT_KEY_SLICE_HEIGHT, "slice-height") KEY(AMEDIAFORMAT_KEY_STRIDE, "stride")
KEY(AMEDIAFORMAT_KEY_WIDTH, "width")

#define MEDIA_NULL(n)  TL_WRAP(n, b_media_null)
#define MEDIA_ERRF(n)  TL_WRAP(n, b_media_err)
#define MEDIA_DATA(n)  TL_DATA(#n, &g_##n)

const tl_bionic_entry tl_tab_ndk[] = {
    /* zlib */
    TL_DIRECT(deflate), TL_DIRECT(deflateEnd), TL_DIRECT(deflateInit2_), TL_DIRECT(deflateInit_),
    TL_DIRECT(inflate), TL_DIRECT(inflateEnd), TL_DIRECT(inflateInit2_), TL_DIRECT(inflateInit_), TL_DIRECT(zError),
    TL_DIRECT(compressBound), TL_DIRECT(zlibVersion), TL_DIRECT(compress), TL_DIRECT(compress2), TL_DIRECT(uncompress), TL_DIRECT(crc32), TL_DIRECT(adler32),
    TL_DIRECT(inflateReset), TL_DIRECT(inflateReset2), TL_DIRECT(deflateReset), TL_DIRECT(inflateSync), TL_DIRECT(deflateParams), TL_DIRECT(deflateSetDictionary), TL_DIRECT(inflateSetDictionary),
    /* looper */
    TL_WRAP("ALooper_prepare", b_ALooper_prepare), TL_WRAP("ALooper_forThread", b_ALooper_forThread),
    TL_WRAP("ALooper_acquire", b_ALooper_acquire), TL_WRAP("ALooper_release", b_ALooper_release),
    TL_WRAP("ALooper_wake", b_ALooper_wake), TL_WRAP("ALooper_pollOnce", b_ALooper_pollOnce), TL_WRAP("ALooper_pollAll", b_ALooper_pollAll),
    TL_WRAP("ALooper_addFd", b_ALooper_addFd), TL_WRAP("ALooper_removeFd", b_ALooper_removeFd),
    /* configuration */
    TL_WRAP("AConfiguration_new", b_AConfiguration_new), TL_WRAP("AConfiguration_delete", b_AConfiguration_delete),
    TL_WRAP("AConfiguration_fromAssetManager", b_AConfiguration_fromAssetManager), TL_WRAP("AConfiguration_getLanguage", b_AConfiguration_getLanguage),
    TL_WRAP("AConfiguration_getCountry", b_AConfiguration_getCountry), TL_WRAP("AConfiguration_getOrientation", b_AConfiguration_getOrientation),
    TL_WRAP("AConfiguration_getDensity", b_AConfiguration_getDensity), TL_WRAP("AConfiguration_getScreenLong", b_AConfiguration_getScreenLong),
    TL_WRAP("AConfiguration_getScreenSize", b_AConfiguration_getScreenSize), TL_WRAP("AConfiguration_getUiModeType", b_AConfiguration_getUiModeType),
    TL_WRAP("AConfiguration_getUiModeNight", b_AConfiguration_getUiModeNight), TL_WRAP("AConfiguration_getKeyboard", b_AConfiguration_getKeyboard),
    TL_WRAP("AConfiguration_getNavigation", b_AConfiguration_getNavigation), TL_WRAP("AConfiguration_getTouchscreen", b_AConfiguration_getTouchscreen),
    TL_WRAP("AConfiguration_getSdkVersion", b_AConfiguration_getSdkVersion),
    /* assets */
    TL_WRAP("AAudio_createStreamBuilder", b_AAudio_createStreamBuilder), TL_WRAP("AAudio_convertResultToText", b_AAudio_convertResultToText),
    TL_WRAP("AAudioStreamBuilder_delete", b_AAudioStreamBuilder_delete), TL_WRAP("AAudioStreamBuilder_setDataCallback", b_AAudioStreamBuilder_setDataCallback),
    TL_WRAP("AAudioStreamBuilder_setDirection", b_AAudioStreamBuilder_setDirection), TL_WRAP("AAudioStreamBuilder_setErrorCallback", b_AAudioStreamBuilder_setErrorCallback),
    TL_WRAP("AAudioStreamBuilder_openStream", b_AAudioStreamBuilder_openStream), TL_WRAP("AAudioStreamBuilder_setDeviceId", b_AAudioStreamBuilder_ignore),
    TL_WRAP("AAudioStreamBuilder_setBufferCapacityInFrames", b_AAudioStreamBuilder_ignore), TL_WRAP("AAudioStreamBuilder_setInputPreset", b_AAudioStreamBuilder_ignore),
    TL_WRAP("AAudioStreamBuilder_setPerformanceMode", b_AAudioStreamBuilder_ignore), TL_WRAP("AAudioStreamBuilder_setUsage", b_AAudioStreamBuilder_ignore),
    TL_WRAP("AAudioStreamBuilder_setSampleRate", b_AAudioStreamBuilder_ignore), TL_WRAP("AAudioStreamBuilder_setChannelCount", b_AAudioStreamBuilder_ignore),
    TL_WRAP("AAudioStreamBuilder_setFormat", b_AAudioStreamBuilder_ignore), TL_WRAP("AAudioStreamBuilder_setSharingMode", b_AAudioStreamBuilder_ignore),
    TL_WRAP("AAudioStream_requestStart", b_AAudioStream_requestStart), TL_WRAP("AAudioStream_requestStop", b_AAudioStream_requestStop),
    TL_WRAP("AAudioStream_close", b_AAudioStream_close), TL_WRAP("AAudioStream_getSampleRate", b_AAudioStream_getSampleRate),
    TL_WRAP("AAudioStream_getChannelCount", b_AAudioStream_getChannelCount), TL_WRAP("AAudioStream_getFormat", b_AAudioStream_getFormat),
    TL_WRAP("AAudioStream_getDeviceId", b_AAudioStream_getDeviceId), TL_WRAP("AAudioStream_getFramesPerBurst", b_AAudioStream_getFramesPerBurst),
    TL_WRAP("AAudioStream_getBufferCapacityInFrames", b_AAudioStream_getBufferCapacityInFrames), TL_WRAP("AAudioStream_getBufferSizeInFrames", b_AAudioStream_getBufferSizeInFrames),
    TL_WRAP("AAudioStream_setBufferSizeInFrames", b_AAudioStream_setBufferSizeInFrames), TL_WRAP("AAudioStream_getXRunCount", b_AAudioStream_getXRunCount),
    TL_WRAP("AAudioStream_getState", b_AAudioStream_getState), TL_WRAP("AAudioStream_read", b_AAudioStream_read),
    TL_WRAP("AAssetManager_openDir", b_AAssetManager_openDir), TL_WRAP("AAssetDir_getNextFileName", b_AAssetDir_getNextFileName),
    TL_WRAP("AAssetDir_close", b_AAssetDir_close), TL_WRAP("deflateBound", b_deflateBound),
    TL_WRAP("AAssetManager_fromJava", b_AAssetManager_fromJava), TL_WRAP("AAssetManager_open", b_AAssetManager_open),
    TL_WRAP("AAsset_close", b_AAsset_close), TL_WRAP("AAsset_read", b_AAsset_read), TL_WRAP("AAsset_getLength", b_AAsset_getLength),
    TL_WRAP("AAsset_getLength64", b_AAsset_getLength), TL_WRAP("AAsset_getRemainingLength", b_AAsset_getRemainingLength),
    TL_WRAP("AAsset_getRemainingLength64", b_AAsset_getRemainingLength), TL_WRAP("AAsset_getBuffer", b_AAsset_getBuffer),
    TL_WRAP("AAsset_seek", b_AAsset_seek), TL_WRAP("AAsset_seek64", b_AAsset_seek), TL_WRAP("AAsset_isAllocated", b_AAsset_isAllocated),
    /* windows */
    TL_WRAP("ANativeWindow_fromSurface", b_ANativeWindow_fromSurface), TL_WRAP("ANativeWindow_acquire", b_ANativeWindow_acquire),
    TL_WRAP("ANativeWindow_release", b_ANativeWindow_release), TL_WRAP("ANativeWindow_getWidth", b_ANativeWindow_getWidth),
    TL_WRAP("ANativeWindow_getHeight", b_ANativeWindow_getHeight), TL_WRAP("ANativeWindow_getFormat", b_ANativeWindow_getFormat),
    TL_WRAP("ANativeWindow_setBuffersGeometry", b_ANativeWindow_setBuffersGeometry),
    TL_WRAP("ANativeWindow_toSurface", b_ANativeWindow_toSurface),
    TL_WRAP("AInputQueue_attachLooper", b_AInputQueue_attachLooper), TL_WRAP("AInputQueue_detachLooper", b_AInputQueue_detachLooper),
    TL_WRAP("AInputQueue_hasEvents", b_AInputQueue_hasEvents), TL_WRAP("AInputQueue_getEvent", b_AInputQueue_getEvent),
    TL_WRAP("AInputQueue_preDispatchEvent", b_AInputQueue_preDispatchEvent), TL_WRAP("AInputQueue_finishEvent", b_AInputQueue_finishEvent),
    TL_WRAP("ANativeActivity_finish", b_ANativeActivity_noop), TL_WRAP("ANativeActivity_setWindowFormat", b_ANativeActivity_input), TL_WRAP("ANativeActivity_setWindowFlags", b_ANativeActivity_flags),
    TL_WRAP("ANativeActivity_showSoftInput", b_ANativeActivity_input), TL_WRAP("ANativeActivity_hideSoftInput", b_ANativeActivity_input),
    /* sensors */
    TL_WRAP("ASensorManager_getInstance", b_ASensorManager_getInstance), TL_WRAP("ASensorManager_getDefaultSensor", b_ASensorManager_getDefaultSensor),
    TL_WRAP("ASensorManager_getSensorList", b_ASensorManager_getSensorList), TL_WRAP("ASensorManager_createEventQueue", b_ASensorManager_createEventQueue),
    TL_WRAP("ASensorManager_destroyEventQueue", b_ASensorManager_destroyEventQueue), TL_WRAP("ASensorEventQueue_enableSensor", b_ASensorEventQueue_enableSensor),
    TL_WRAP("ASensorEventQueue_disableSensor", b_ASensorEventQueue_disableSensor), TL_WRAP("ASensorEventQueue_setEventRate", b_ASensorEventQueue_setEventRate),
    TL_WRAP("ASensorEventQueue_hasEvents", b_ASensorEventQueue_hasEvents), TL_WRAP("ASensorEventQueue_getEvents", b_ASensorEventQueue_getEvents),
    TL_WRAP("ASensor_getName", b_ASensor_getName), TL_WRAP("ASensor_getVendor", b_ASensor_getVendor), TL_WRAP("ASensor_getType", b_ASensor_getType),
    TL_WRAP("ASensor_getResolution", b_ASensor_getResolution), TL_WRAP("ASensor_getMinDelay", b_ASensor_getMinDelay),
    /* media */
    MEDIA_NULL("AMediaCodec_createDecoderByType"), MEDIA_NULL("AMediaExtractor_new"), MEDIA_NULL("AMediaCodec_getOutputFormat"),
    MEDIA_NULL("AMediaExtractor_getTrackFormat"), MEDIA_NULL("AMediaCodec_getInputBuffer"), MEDIA_NULL("AMediaCodec_getOutputBuffer"),
    MEDIA_ERRF("AMediaCodec_configure"), MEDIA_ERRF("AMediaCodec_start"), MEDIA_ERRF("AMediaCodec_stop"), MEDIA_ERRF("AMediaCodec_flush"),
    MEDIA_ERRF("AMediaCodec_delete"), MEDIA_ERRF("AMediaCodec_dequeueInputBuffer"), MEDIA_ERRF("AMediaCodec_dequeueOutputBuffer"),
    MEDIA_ERRF("AMediaCodec_queueInputBuffer"), MEDIA_ERRF("AMediaCodec_releaseOutputBuffer"),
    MEDIA_ERRF("AMediaExtractor_setDataSource"), MEDIA_ERRF("AMediaExtractor_setDataSourceFd"), MEDIA_ERRF("AMediaExtractor_selectTrack"),
    MEDIA_ERRF("AMediaExtractor_seekTo"), MEDIA_ERRF("AMediaExtractor_delete"), MEDIA_ERRF("AMediaExtractor_advance"),
    MEDIA_ERRF("AMediaExtractor_readSampleData"), MEDIA_ERRF("AMediaExtractor_getSampleTime"), MEDIA_ERRF("AMediaExtractor_getSampleTrackIndex"),
    TL_WRAP("AMediaExtractor_getTrackCount", b_media_zero), MEDIA_ERRF("AMediaFormat_delete"), MEDIA_ERRF("AMediaFormat_getFloat"),
    MEDIA_ERRF("AMediaFormat_getInt32"), MEDIA_ERRF("AMediaFormat_getInt64"), MEDIA_ERRF("AMediaFormat_getString"),
    MEDIA_ERRF("AMediaFormat_setInt32"),
    MEDIA_DATA(AMEDIAFORMAT_KEY_CHANNEL_COUNT), MEDIA_DATA(AMEDIAFORMAT_KEY_COLOR_FORMAT), MEDIA_DATA(AMEDIAFORMAT_KEY_COLOR_RANGE),
    MEDIA_DATA(AMEDIAFORMAT_KEY_COLOR_STANDARD), MEDIA_DATA(AMEDIAFORMAT_KEY_DURATION), MEDIA_DATA(AMEDIAFORMAT_KEY_ENCODER_DELAY),
    MEDIA_DATA(AMEDIAFORMAT_KEY_FRAME_RATE), MEDIA_DATA(AMEDIAFORMAT_KEY_HEIGHT), MEDIA_DATA(AMEDIAFORMAT_KEY_LANGUAGE),
    MEDIA_DATA(AMEDIAFORMAT_KEY_MIME), MEDIA_DATA(AMEDIAFORMAT_KEY_ROTATION), MEDIA_DATA(AMEDIAFORMAT_KEY_SAMPLE_RATE),
    MEDIA_DATA(AMEDIAFORMAT_KEY_SLICE_HEIGHT), MEDIA_DATA(AMEDIAFORMAT_KEY_STRIDE), MEDIA_DATA(AMEDIAFORMAT_KEY_WIDTH),
    TL_END
};
