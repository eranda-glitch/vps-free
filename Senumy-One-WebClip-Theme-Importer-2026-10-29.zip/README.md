# Senumy One

An original, installable web phone experience built with plain HTML, CSS, and JavaScript.

Serve the `dist` directory over HTTPS, then use **Add to Home Screen** on iPhone for full-screen standalone mode.

See `WEBCLIP-SETUP.md` for manual iPhone installation and optional `.mobileconfig` generation.
