# Install Senumy One on iPhone

## Recommended: Add to Home Screen

1. Upload everything inside `dist` to an HTTPS website.
2. Open the HTTPS address in Safari on the iPhone.
3. Tap **Share**, choose **Add to Home Screen**, then tap **Add**.

Senumy One launches in standalone full-screen mode with its own icon. Imported themes are stored locally on that device.

## Optional configuration profile

After the final HTTPS address is known, generate a Web Clip profile on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\webclip\make-webclip.ps1 -Url "https://your-domain.example/"
```

This creates `webclip\Senumy-One.mobileconfig` with the correct URL and embedded Senumy icon. Host that file with MIME type `application/x-apple-aspen-config`, open it in Safari, and follow the iOS profile-installation prompts.

Unsigned profiles display an iOS warning. For public distribution, sign the profile or deploy it through an MDM service. The Web Clip changes only the Senumy One experience; it cannot modify the real iOS interface.
