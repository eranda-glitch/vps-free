param(
  [Parameter(Mandatory=$true)][ValidatePattern('^https://')][string]$Url,
  [string]$Output = (Join-Path $PSScriptRoot 'Senumy-One.mobileconfig')
)

$templatePath = Join-Path $PSScriptRoot 'senumy-webclip.mobileconfig.template'
$iconPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'dist\apple-touch-icon.png'
$template = Get-Content -LiteralPath $templatePath -Raw
$escapedUrl = [System.Security.SecurityElement]::Escape($Url.TrimEnd('/') + '/')
$icon = [Convert]::ToBase64String([IO.File]::ReadAllBytes($iconPath))
$profile = $template.Replace('__WEBCLIP_URL__', $escapedUrl).Replace('__ICON_BASE64__', $icon)
[IO.File]::WriteAllText($Output, $profile, [Text.UTF8Encoding]::new($false))
Get-Item -LiteralPath $Output
