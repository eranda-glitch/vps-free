<?php
declare(strict_types=1);
require dirname(__DIR__) . '/private/Core.php';
use IpaBuilder\GitHub;
use function IpaBuilder\validateInput;
use function IpaBuilder\extractIpa;
$checks = 0;
function check(bool $condition, string $message): void {
    global $checks; $checks++;
    if (!$condition) throw new RuntimeException($message);
}
function rejects(callable $callback, string $message): void {
    try { $callback(); } catch (RuntimeException|InvalidArgumentException $error) { check(true, $message); return; }
    check(false, $message);
}
$valid = ['app_name' => 'Flappy Web', 'website_url' => 'https://flappybird.io/', 'icon_url' => '', 'bundle_id' => 'com.myapps.flappyweb'];
check(validateInput($valid) === $valid, 'Valid input should survive unchanged');
foreach (['javascript:alert(1)', 'file:///etc/passwd', 'https://user:secret@example.com/', "https://exam\nple.com/", 'https://127.0.0.1/', 'https://app.local/', 'http://example.com/'] as $url) {
    rejects(fn() => validateInput(array_replace($valid, ['website_url' => $url])), 'Unsafe URL accepted');
}
foreach (['$(touch bad)', '<script>', '', str_repeat('a', 31)] as $name) {
    rejects(fn() => validateInput(array_replace($valid, ['app_name' => $name])), 'Invalid name accepted');
}
foreach (['com.test;whoami', '../path', 'com', '1com.app'] as $bundle) {
    rejects(fn() => validateInput(array_replace($valid, ['bundle_id' => $bundle])), 'Invalid bundle accepted');
}
check(validateInput(array_replace($valid, ['website_url' => 'https://example.com/?a=%22&b=%24%28hello%29']))['website_url'] !== '', 'Encoded query should be treated as data');
check(validateInput(array_replace($valid, ['icon_url' => 'https://example.com/icon.webp']))['icon_url'] !== '', 'HTTPS icon URL should be accepted');
foreach (['http://example.com/icon.png', 'file:///tmp/icon.png', 'https://127.0.0.1/icon.png', "https://exam\nple.com/icon.png"] as $iconUrl) {
    rejects(fn() => validateInput(array_replace($valid, ['icon_url' => $iconUrl])), 'Unsafe icon URL accepted');
}
$config = ['github_owner' => 'owner', 'github_repo' => 'repo', 'github_ref' => 'main', 'github_workflow' => 'build-website-ipa.yml', 'github_token' => 'TEST-TOKEN'];
$id = str_repeat('a', 32);
$transport = function ($method, $path, $body) use ($id, $valid): array {
    check($method === 'POST', 'Dispatch must use POST');
    check($path === '/repos/owner/repo/actions/workflows/build-website-ipa.yml/dispatches', 'Dispatch path');
    check($body['inputs'] === $valid + ['request_id' => $id], 'Dispatch must send original inputs as JSON data');
    return ['status' => 200, 'data' => ['workflow_run_id' => 42], 'headers' => []];
};
check((new GitHub($config, $transport))->dispatch($valid, $id) === 42, 'New API dispatch response');
$run = ['id' => 42, 'display_title' => 'Web IPA - ' . $id, 'head_branch' => 'main', 'event' => 'workflow_dispatch', 'status' => 'completed', 'conclusion' => 'success'];
$api = new GitHub($config, fn() => ['status' => 200, 'data' => $run]);
check($api->run(['request_id' => $id, 'run_id' => 42])['id'] === 42, 'Run identity');
rejects(fn() => $api->run(['request_id' => str_repeat('b', 32), 'run_id' => 42]), 'Must reject a different request’s run');
$fallback = new GitHub($config, fn() => ['status' => 200, 'data' => ['workflow_runs' => [$run]]]);
check($fallback->run(['request_id' => $id])['id'] === 42, 'Find exact request ID for legacy dispatch');
$missing = new GitHub($config, fn() => ['status' => 200, 'data' => ['workflow_runs' => []]]);
check($missing->run(['request_id' => $id]) === null, 'Unknown run must not select an unrelated build');
$denied = new GitHub($config, fn() => ['status' => 401, 'data' => ['message' => 'TEST-TOKEN']]);
try { $denied->dispatch($valid, $id); check(false, '401 must fail'); }
catch (RuntimeException $error) { check(!str_contains($error->getMessage(), 'TEST-TOKEN'), 'Error must not leak token or raw GitHub response'); }
$badRedirect = new GitHub($config, fn() => ['status' => 302, 'headers' => ['location' => 'https://evil.example/file.zip'], 'data' => []]);
rejects(fn() => $badRedirect->downloadIpa(1), 'Artifact download must reject an unexpected host');
$zipPath = tempnam(sys_get_temp_dir(), 'test-ipa-');
$zip = new ZipArchive(); $zip->open($zipPath, ZipArchive::OVERWRITE);
$zip->addFromString('../escape.txt', 'DO NOT EXTRACT');
$zip->addFromString('WebApp-unsigned.ipa', 'test IPA bytes'); $zip->close();
$ipa = extractIpa($zipPath);
check(file_get_contents($ipa) === 'test IPA bytes', 'Read only expected entry, never extract arbitrary paths');
unlink($ipa); unlink($zipPath);
$zipPath = tempnam(sys_get_temp_dir(), 'test-ipa-');
$zip = new ZipArchive(); $zip->open($zipPath, ZipArchive::OVERWRITE); $zip->addFromString('wrong.ipa', 'wrong'); $zip->close();
rejects(fn() => extractIpa($zipPath), 'Missing expected IPA must fail'); unlink($zipPath);
echo "$checks checks passed.\n";
