# IPA Studio — PHP website-to-IPA builder

Runs on PHP 8.2+ with cURL, ZIP, OpenSSL and sessions. No Composer, Node, database, Mac or Apple account is needed on the PHP server. GitHub Actions compiles the iPhone app on macOS.

This tool makes an **unsigned web-wrapper IPA**, like the Flappy Web app. It does not convert arbitrary PHP code, Android APKs or desktop programs to native iOS apps. The website remains online and the app loads it using WKWebView. It uses a supplied default icon, portrait orientation, and iOS 15 minimum. Sites requiring special native permissions, downloads, popup-based sign-in or external-app integration may require app changes. Signing and real-device testing are separate steps.

## 1. Install the GitHub workflow

In your private `eranda-glitch/vps-free` repository:

1. Open `.github/workflows` and choose **Add file → Upload files**.
2. Upload `workflow/build-website-ipa.yml` from this package and commit it to the default branch (`main`).
3. Confirm **Build Website IPA** appears under Actions.

The workflow is self-contained; it includes the app template and default icon. It does not replace your existing Flappy Web workflow or files. Only upload the YAML file, not your PHP configuration or token.

To use another repository, install the same YAML file there and change the owner/repository values in the PHP configuration. Use a branch name for `github_ref`; run matching uses the branch name returned by GitHub. GitHub Actions must be enabled and have available macOS build minutes/storage. Private repositories may incur usage charges under your GitHub plan.

## 2. Create a repository-scoped GitHub token

In GitHub **Settings → Developer settings → Personal access tokens → Fine-grained tokens**, generate a token:

- Resource owner: the owner of your build repository.
- Repository access: **Only select repositories**, then select the build repository.
- Repository permissions: **Actions: Read and write**. Metadata read access is automatic.
- Set an expiration date and replace the token before it expires.

The token triggers builds, reads status and downloads artifacts. This tool never needs a token with permission to edit your repository files. Do not paste the token into chat, put it in JavaScript or commit it to GitHub.

## 3. Configure PHP

Copy `private/config.example.php` to `private/config.local.php`. Fill in `github_token`, owner, repository and branch. The default workflow name is `build-website-ipa.yml`.

Set `password_hash` to the output of the following command, replacing the example password with a long, unique password. Run locally if cPanel has no terminal, then paste only the resulting hash into the server configuration:

```text
php -r "echo password_hash('replace-with-your-long-password', PASSWORD_DEFAULT), PHP_EOL;"
```

Keep `secure_cookie` false for local HTTP. Set it true on HTTPS hosting. The app also detects HTTPS directly; if a hosting proxy terminates HTTPS, set this explicitly. PHP session storage must be writable. PHP's temporary directory must be writable for artifact downloads. Outbound HTTPS to api.github.com and GitHub’s artifact storage must be allowed.

## 4A. Run locally on Windows / XAMPP

Option A: double-click `start-local.bat`, then visit **http://127.0.0.1:8088**. It uses `C:\xampp\php\php.exe`, or `php` from PATH. Keep the terminal running. The development server only listens on this PC.

Option B: copy the `php-ipa-builder` folder to `C:\xampp\htdocs`, start Apache in XAMPP, and open **http://localhost/php-ipa-builder/**.

If PHP reports a certificate verification error, configure `curl.cainfo` in the active php.ini to a current CA certificate bundle from https://curl.se/docs/caextract.html and restart PHP/Apache. Do not disable TLS verification.

## 4B. Run on cPanel

1. Select PHP 8.2 or newer. Enable **curl**, **zip**, **openssl** and sessions.
2. Upload the package to a folder such as `public_html/ipa-builder` and extract it.
3. Keep the root `.htaccess` and `private/.htaccess` files. File Manager may hide dotfiles; enable “Show Hidden Files”.
4. Create/edit `private/config.local.php` as above. Set `secure_cookie` to true.
5. Enable HTTPS for the domain, then open `https://your-domain.example/ipa-builder/`.
6. Confirm `https://your-domain.example/ipa-builder/private/config.example.php` returns **403 Forbidden**. The private directory must not be web-accessible. The supplied rules assume Apache or LiteSpeed with `.htaccess` support; ask your host for equivalent deny rules on other servers before adding secrets.

For a public-facing installation, use hosting-level login rate limiting in addition to the app’s session-based retry delay. This is a single-operator tool, not a multi-user billing service. You can run separate local and hosted copies with the same repository/token; each browser session tracks its own jobs.

## 5. Build and download

1. Sign in using your workspace password.
2. Enter an HTTPS website URL, app name, and unique bundle ID.
3. Click **Build my IPA**. Status refreshes automatically every eight seconds.
4. Click **Download IPA** when ready. PHP downloads GitHub’s ZIP, reads only the expected IPA entry, and sends the `.ipa` file to your browser.
5. Sign and provision the IPA using your preferred sideloading method, then test on your iPhone.

URLs and names become build inputs in your repository, and the URL is embedded in the app. Use public URLs rather than URLs containing secrets. The PHP server does not fetch the website during a build. The workflow compiles and checks the package; it does not verify that every website feature works on iOS.

Build history is limited to the latest ten requests in the current PHP session. Signing out or losing the session removes the local history; the actual builds remain available in GitHub Actions. Artifacts are retained for 30 days. Run logs are available from the **View logs** button. If a dispatch request times out, the app checks the unique request ID before suggesting a new build, reducing duplicate builds.

## Development and verification

```text
php tests/run.php
php tools/make-workflow.php
```

The second command regenerates the self-contained workflow from the readable files in `private/template`. After editing the template, regenerate and replace the YAML in GitHub. Use the provided router when running PHP’s development server; `.htaccess` alone does not protect private files on that server.

GitHub API references:
- https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event
- https://docs.github.com/en/rest/actions/artifacts#download-an-artifact

## Troubleshooting

- **Setup needed:** the token/password hash is missing or cURL/ZIP is disabled.
- **401:** the GitHub token is wrong or expired.
- **403:** check token permissions, repository policies and API limits.
- **404:** check owner, repository, workflow filename and token repository access.
- **422 / no run found:** install the supplied workflow on the default branch and ensure the configured branch exists.
- **Queued for a long time:** check GitHub Actions runner availability and billing limits.
- **Build failed:** use View logs. Do not share logs containing private URL parameters.
- **IPA will not install:** the output is intentionally unsigned; it must be signed and provisioned for your device.
