<?php
declare(strict_types=1);
require __DIR__ . '/private/Core.php';
use IpaBuilder\GitHub;

ini_set('display_errors', '0');
$config = require __DIR__ . '/private/config.example.php';
if (is_file(__DIR__ . '/private/config.local.php')) $config = array_replace($config, require __DIR__ . '/private/config.local.php');
$secure = !empty($config['secure_cookie']) || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$sessionPath = session_save_path();
if ($sessionPath === '' || !is_dir($sessionPath) || !is_writable($sessionPath)) {
    $sessionPath = __DIR__ . '/private/sessions';
    if (!is_dir($sessionPath)) mkdir($sessionPath, 0700, true);
    session_save_path($sessionPath);
}
session_name('ipa_builder');
session_start(['use_strict_mode' => 1, 'cookie_httponly' => true, 'cookie_secure' => $secure, 'cookie_samesite' => 'Strict']);
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: https:; connect-src 'self'; frame-src https:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
$ready = extension_loaded('curl') && extension_loaded('zip') && !empty($config['github_token']) && !empty($config['password_hash']);
$action = (string)($_GET['action'] ?? '');
$error = '';
function escape(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function jsonResponse(array $data, int $status = 200): never {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_THROW_ON_ERROR); exit;
}
function csrfCheck(): void {
    if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) {
        throw new RuntimeException('Your session changed. Refresh the page and try again.');
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($action, ['login', 'logout'], true)) {
    try {
        csrfCheck();
        if ($action === 'logout') {
            $_SESSION = []; session_regenerate_id(true);
            header('Location: index.php', true, 303); exit;
        }
        if (!$ready) throw new RuntimeException('Finish the server setup first.');
        if (time() < ($_SESSION['retry_at'] ?? 0)) throw new RuntimeException('Please wait a few seconds before trying again.');
        if (!password_verify((string)($_POST['password'] ?? ''), $config['password_hash'])) {
            $_SESSION['retry_at'] = time() + 3;
            throw new RuntimeException('The password is incorrect.');
        }
        session_regenerate_id(true);
        $_SESSION['authenticated'] = true;
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        header('Location: index.php', true, 303); exit;
    } catch (RuntimeException $exception) { $error = $exception->getMessage(); }
}
$authenticated = !empty($_SESSION['authenticated']);
if (in_array($action, ['build', 'status', 'download'], true)) {
    try {
        if (!$ready || !$authenticated) jsonResponse(['error' => 'Sign in before using the builder.'], 401);
        $github = new GitHub($config);
        if ($action === 'build') {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'POST required.'], 405);
            csrfCheck();
            if (time() - ($_SESSION['last_dispatch'] ?? 0) < 30) jsonResponse(['error' => 'Wait 30 seconds before starting another build.'], 429);
            $input = IpaBuilder\validateInput($_POST);
            foreach ($_SESSION['jobs'] ?? [] as $previous) {
                if (!in_array($previous['state'] ?? '', ['completed', 'not_found', 'dispatch_error'], true)
                    && time() - $previous['created_at'] < 1800) {
                    throw new RuntimeException('A build is already active. Check its status before starting another.');
                }
            }
            $requestId = bin2hex(random_bytes(16));
            $job = $input + ['request_id' => $requestId, 'created_at' => time(), 'state' => 'waiting'];
            // Remember the request before contacting GitHub: a network timeout may still dispatch a build.
            $_SESSION['last_dispatch'] = time();
            $_SESSION['jobs'][$requestId] = $job;
            $_SESSION['jobs'] = array_slice($_SESSION['jobs'], -10, null, true);
            try {
                $_SESSION['jobs'][$requestId]['run_id'] = $github->dispatch($input, $requestId);
                jsonResponse(['job' => $_SESSION['jobs'][$requestId]]);
            } catch (RuntimeException $exception) {
                jsonResponse(['job' => $_SESSION['jobs'][$requestId], 'warning' => $exception->getMessage() . ' Checking whether GitHub received the request.']);
            }
        }
        $id = (string)($_GET['id'] ?? '');
        if (!isset($_SESSION['jobs'][$id])) jsonResponse(['error' => 'This build does not belong to your current session.'], 404);
        $job = &$_SESSION['jobs'][$id];
        if ($action === 'status' && time() - ($job['checked_at'] ?? 0) < 7 && isset($job['snapshot'])) jsonResponse($job['snapshot']);
        $run = $github->run($job);
        if (!$run) {
            $job['state'] = time() - $job['created_at'] > 300 ? 'not_found' : 'waiting';
            $snapshot = ['job' => $job, 'status' => $job['state'], 'conclusion' => null, 'download_ready' => false];
        } else {
            $job['run_id'] = (int)$run['id'];
            $job['state'] = $run['status'];
            $artifact = $run['status'] === 'completed' && $run['conclusion'] === 'success' ? $github->artifact($job['run_id']) : null;
            $downloadReady = $artifact && empty($artifact['expired']);
            if ($action === 'download') {
                if (!$downloadReady) throw new RuntimeException('The IPA is not available yet, or the artifact has expired.');
                $filename = preg_replace('/[^A-Za-z0-9_-]+/', '-', $job['app_name']) . '-unsigned.ipa';
                session_write_close();
                $file = $github->downloadIpa((int)$artifact['id']);
                try {
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . $filename . '"');
                    header('Content-Length: ' . filesize($file));
                    readfile($file);
                } finally { unlink($file); }
                exit;
            }
            $snapshot = ['job' => array_diff_key($job, ['snapshot' => true]), 'status' => $run['status'],
                'conclusion' => $run['conclusion'], 'run_url' => $github->runLink($job['run_id']),
                'download_ready' => (bool)$downloadReady, 'expired' => (bool)($artifact['expired'] ?? false)];
        }
        unset($snapshot['job']['snapshot']);
        $job['checked_at'] = time(); $job['snapshot'] = $snapshot;
        jsonResponse($snapshot);
    } catch (InvalidArgumentException $exception) { jsonResponse(['error' => $exception->getMessage()], 422);
    } catch (RuntimeException $exception) { jsonResponse(['error' => $exception->getMessage()], 502);
    } catch (Throwable $exception) { jsonResponse(['error' => 'The server could not complete the request. Check your PHP configuration.'], 500); }
}
$jobs = $authenticated ? array_reverse(array_values($_SESSION['jobs'] ?? [])) : [];
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?= escape($_SESSION['csrf']) ?>"><title>IPA Studio — Website to iPhone</title>
<link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="assets/preview.css"><script src="assets/app.js" defer></script></head>
<body>
<header class="topbar"><a class="brand" href="index.php"><span class="brand-icon">↗</span> IPA<span>Studio</span></a>
<div class="top-right"><span class="tag">Website → iPhone</span><?php if ($authenticated): ?>
<form method="post" action="?action=logout"><input type="hidden" name="csrf" value="<?= escape($_SESSION['csrf']) ?>"><button class="text-button">Sign out</button></form><?php endif ?></div></header>
<main><section class="intro"><p class="eyebrow">YOUR WEBSITE. AN APP OF ITS OWN.</p><h1>From a link<br>to an <span>iPhone app.</span></h1>
<p class="lede">Give your website a home on iPhone. Enter a URL, choose a name, and build an IPA ready for signing.</p>
<div class="benefits"><span>✓ No Mac needed</span><span>✓ Your GitHub account</span><span>✓ Downloadable IPA</span></div></section>
<?php if (!$ready): ?>
<aside class="setup"><strong>One-time setup needed</strong><p>Copy <code>private/config.example.php</code> to <code>private/config.local.php</code>, add your GitHub token and password hash, and install the included workflow. See <code>SETUP.md</code> for XAMPP and cPanel instructions.</p>
<div class="setup-checks"><span><?= extension_loaded('curl') ? '✓' : '○' ?> PHP cURL</span><span><?= extension_loaded('zip') ? '✓' : '○' ?> PHP ZIP</span><span><?= !empty($config['github_token']) ? '✓' : '○' ?> GitHub token</span><span><?= !empty($config['password_hash']) ? '✓' : '○' ?> Login password</span></div></aside>
<?php endif ?>
<?php if ($ready && !$authenticated): ?>
<section class="login card"><p class="eyebrow">PRIVATE WORKSPACE</p><h2>Welcome back.</h2><p>Sign in to create and download your apps.</p>
<?php if ($error): ?><p class="message error" role="alert"><?= escape($error) ?></p><?php endif ?>
<form action="?action=login" method="post"><input type="hidden" name="csrf" value="<?= escape($_SESSION['csrf']) ?>">
<label for="password">Workspace password</label><input id="password" name="password" type="password" autocomplete="current-password" required><button class="primary">Open workspace <span>→</span></button></form></section>
<?php else: ?>
<div class="workspace"><section class="card builder"><div class="card-heading"><div><p class="eyebrow">01 / CONFIGURE</p><h2>Create your app</h2></div><span class="pill">iOS 15+</span></div>
<form id="build-form"><fieldset <?= !$ready ? 'disabled' : '' ?>><label for="website-url">Website URL</label><input id="website-url" name="website_url" type="url" placeholder="https://your-website.com" value="https://flappybird.io/" required maxlength="2048"><p class="hint">Use an HTTPS website that works well on mobile.</p>
<label for="app-name">App name</label><input id="app-name" name="app_name" value="Flappy Web" maxlength="30" required pattern="[A-Za-z0-9][A-Za-z0-9 ._\-]{0,29}"><p class="hint">The name shown on your iPhone’s home screen.</p>
<label for="icon-url">App icon URL <span class="optional">Optional</span></label><input id="icon-url" name="icon_url" type="url" placeholder="https://example.com/app-icon.webp" maxlength="2048"><p class="hint">Use a square HTTPS PNG, JPEG or WebP image. GitHub converts it to iOS icon sizes.</p>
<label for="bundle-id">Bundle ID</label><input id="bundle-id" name="bundle_id" value="com.myapps.flappyweb" maxlength="150" required><p class="hint">A unique identifier, such as com.yourname.myapp.</p>
<div class="output-note"><span class="note-icon">↗</span><div><strong>Unsigned IPA</strong><p>You’ll sign the file with your preferred sideloading tool. The app loads your live website and needs internet access.</p></div></div>
<button class="primary" id="build-button" type="submit">Build my IPA <span>→</span></button><p class="under-button">Builds use your GitHub Actions allowance.</p></fieldset></form><p id="form-message" class="message" role="alert" hidden></p></section>
<aside class="preview-panel">
<div class="preview-heading"><div><p class="eyebrow">LIVE PREVIEW</p><h2>See it as an app</h2></div><span class="live-pill"><i></i> Live</span></div>
<div class="preview-stage">
<div class="app-identity"><span class="app-icon identity-icon" id="identity-icon-fallback">↗</span><img class="app-icon app-icon-image identity-icon" id="identity-icon" alt="App icon preview" hidden><div><span>APP ICON</span><strong id="identity-name">Flappy Web</strong><small id="identity-domain">flappybird.io</small></div></div>
<div class="phone"><div class="island"></div><div class="phone-top"><span>9:41</span><span class="phone-signals" aria-hidden="true">▮▮▮ ◉ ▰</span></div>
<div class="browser-preview"><iframe id="preview-frame" title="Website mobile preview" sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer"></iframe>
<div class="splash-screen" id="splash-screen"><div class="splash-glow"></div><span class="app-icon splash-icon" id="preview-icon-fallback">↗</span><img class="app-icon app-icon-image splash-icon" id="preview-icon" alt="App splash icon" hidden><h3 id="preview-name">Flappy Web</h3><p>Opening <span id="preview-domain">flappybird.io</span></p><span class="loading-line"><i></i></span></div>
</div><div class="home-bar"></div></div>
</div>
<div class="preview-actions"><button type="button" class="preview-action" id="replay-preview"><span>↻</span> Replay launch</button><button type="button" class="preview-action" id="reload-preview"><span>⟳</span> Reload</button><a class="preview-action" id="open-preview" href="https://flappybird.io/" target="_blank" rel="noopener noreferrer"><span>↗</span> Open site</a></div>
<p class="preview-caption">A live mobile preview of the launch experience. Some websites block embedded viewing; use <strong>Open site</strong> when that happens.</p></aside></div>
<section class="card builds"><div class="card-heading"><div><p class="eyebrow">02 / BUILD & DOWNLOAD</p><h2>Recent builds</h2></div><span class="pill">This session</span></div>
<p id="empty-builds" class="empty" <?= $jobs ? 'hidden' : '' ?>>Your first app starts with a link. Builds will appear here.</p><div id="build-list">
<?php foreach ($jobs as $job): ?><article class="build-row" data-id="<?= escape($job['request_id']) ?>"><div><strong><?= escape($job['app_name']) ?></strong><p class="build-status">Checking build…</p></div><div class="build-actions"></div></article><?php endforeach ?>
</div><p class="hint">Artifacts are kept for 30 days. Download your IPA before it expires. Signing and physical-device testing happen separately.</p></section>
<?php endif ?>
<footer><span>IPA Studio</span><p>Built for your websites. Powered by GitHub Actions.</p></footer></main></body></html>
