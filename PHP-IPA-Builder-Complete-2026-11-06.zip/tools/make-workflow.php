<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$root = dirname(__DIR__);
$workflow = <<<'YAML'
name: Build Website IPA
run-name: Web IPA - ${{ inputs.request_id }}
on:
  workflow_dispatch:
    inputs:
      website_url:
        description: HTTPS website to open
        type: string
        required: true
      app_name:
        description: App display name (1-30 characters)
        type: string
        required: true
      icon_url:
        description: Optional HTTPS PNG, JPEG or WebP app icon
        type: string
        required: false
        default: ''
      bundle_id:
        description: Unique bundle ID (com.yourname.myapp)
        type: string
        required: true
      request_id:
        description: Request identifier supplied by PHP IPA Builder
        type: string
        required: true
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 10
    steps:
      - name: Validate app settings
        env:
          WEBSITE_URL: ${{ inputs.website_url }}
          APP_NAME: ${{ inputs.app_name }}
          ICON_URL: ${{ inputs.icon_url }}
          BUNDLE_ID: ${{ inputs.bundle_id }}
          REQUEST_ID: ${{ inputs.request_id }}
        run: |
          python3 - <<'PY'
          import os, re, urllib.parse
          url = os.environ['WEBSITE_URL']
          icon_url = os.environ['ICON_URL']
          parsed = urllib.parse.urlsplit(url)
          assert len(url) <= 2048 and parsed.scheme == 'https' and parsed.hostname and '.' in parsed.hostname, 'Use a public HTTPS URL'
          assert parsed.username is None and parsed.password is None, 'Credentials in URLs are not supported'
          assert not re.search(r'[\x00-\x20\x7f]', url), 'Invalid URL characters'
          assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 ._-]{0,29}', os.environ['APP_NAME']), 'Invalid app name'
          if icon_url:
              icon = urllib.parse.urlsplit(icon_url)
              assert len(icon_url) <= 2048 and icon.scheme == 'https' and icon.hostname and '.' in icon.hostname, 'Use a public HTTPS icon URL'
              assert icon.username is None and icon.password is None, 'Credentials in icon URLs are not supported'
              assert not re.search(r'[\x00-\x20\x7f]', icon_url), 'Invalid icon URL characters'
          assert len(os.environ['BUNDLE_ID']) <= 150 and re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*(?:\.[A-Za-z][A-Za-z0-9-]*)+', os.environ['BUNDLE_ID']), 'Invalid bundle ID'
          assert re.fullmatch(r'[a-f0-9]{32}', os.environ['REQUEST_ID']), 'Invalid request identifier'
          PY
      - name: Create native app template
        run: |
YAML;
$workflow .= "\n";
foreach (['WebApp.m', 'Info.plist', 'build-ios.sh'] as $filename) {
    $content = str_replace("\r\n", "\n", file_get_contents($root . '/private/template/' . $filename));
    $workflow .= "          cat > '$filename' <<'IPA_TEMPLATE_EOF'\n";
    foreach (explode("\n", rtrim($content)) as $line) $workflow .= '          ' . $line . "\n";
    $workflow .= "          IPA_TEMPLATE_EOF\n";
}
foreach (['AppIcon60x60@2x.png', 'AppIcon60x60@3x.png'] as $filename) {
    $encoded = base64_encode(file_get_contents($root . '/private/template/' . $filename));
    $workflow .= "          printf '%s' '$encoded' | base64 --decode > '$filename'\n";
}
$workflow .= <<<'YAML'
      - name: Apply custom app icon
        if: ${{ inputs.icon_url != '' }}
        env:
          ICON_URL: ${{ inputs.icon_url }}
        run: |
          curl --fail --location --silent --show-error --proto '=https' --proto-redir '=https' --connect-timeout 10 --max-time 30 --max-filesize 5242880 "$ICON_URL" -o AppIconSource
          sips -s format png AppIconSource --out AppIcon.png
          sips -z 120 120 AppIcon.png --out AppIcon60x60@2x.png
          sips -z 180 180 AppIcon.png --out AppIcon60x60@3x.png
          test "$(stat -f%z AppIcon60x60@2x.png)" -gt 0
          test "$(stat -f%z AppIcon60x60@3x.png)" -gt 0
      - name: Apply app settings
        env:
          WEBSITE_URL: ${{ inputs.website_url }}
          APP_NAME: ${{ inputs.app_name }}
          BUNDLE_ID: ${{ inputs.bundle_id }}
        run: |
          python3 - <<'PY'
          import os, plistlib
          with open('Info.plist', 'rb') as f:
              info = plistlib.load(f)
          info['CFBundleDisplayName'] = os.environ['APP_NAME']
          info['CFBundleIdentifier'] = os.environ['BUNDLE_ID']
          info['WebsiteURL'] = os.environ['WEBSITE_URL']
          with open('Info.plist', 'wb') as f:
              plistlib.dump(info, f)
          PY
      - name: Build and verify unsigned iPhone IPA
        run: bash build-ios.sh iphoneos
      - name: Upload IPA
        uses: actions/upload-artifact@v7
        with:
          name: website-ipa
          path: artifacts/WebApp-unsigned.ipa
          if-no-files-found: error
          retention-days: 30
      - name: Upload build checks
        uses: actions/upload-artifact@v7
        with:
          name: build-checks
          path: artifacts/*.txt
          if-no-files-found: error
          retention-days: 30
YAML;
file_put_contents($root . '/workflow/build-website-ipa.yml', $workflow . "\n");
echo "Created workflow/build-website-ipa.yml\n";
