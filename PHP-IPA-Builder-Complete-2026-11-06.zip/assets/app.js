const form = document.querySelector('#build-form');
const appName = document.querySelector('#app-name');
const website = document.querySelector('#website-url');
const iconUrl = document.querySelector('#icon-url');
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const list = document.querySelector('#build-list');
const timers = new Map();
let previewTimer;
let previewUrl = '';

function normalizedPreviewUrl() {
  if (!website) return '';
  try {
    const url = new URL(website.value.trim());
    return url.protocol === 'https:' ? url.href : '';
  } catch { return ''; }
}

function setPreviewIcon(value) {
  const pairs = [
    [document.querySelector('#preview-icon'), document.querySelector('#preview-icon-fallback')],
    [document.querySelector('#identity-icon'), document.querySelector('#identity-icon-fallback')]
  ];
  pairs.forEach(([image, fallback]) => {
    if (!image || !fallback) return;
    image.hidden = !value; fallback.hidden = !!value;
    if (value) image.src = value;
  });
}

function launchPreview(forceReload = false) {
  const frame = document.querySelector('#preview-frame');
  const splash = document.querySelector('#splash-screen');
  const openLink = document.querySelector('#open-preview');
  if (!frame || !splash) return;
  const url = normalizedPreviewUrl();
  clearTimeout(previewTimer);
  splash.classList.remove('is-hidden');
  if (openLink) {
    openLink.href = url || '#';
    openLink.classList.toggle('is-disabled', !url);
    openLink.setAttribute('aria-disabled', String(!url));
  }
  if (!url) {
    frame.removeAttribute('src');
    previewUrl = '';
    return;
  }
  if (forceReload || previewUrl !== url) {
    frame.src = url;
    previewUrl = url;
  }
  previewTimer = setTimeout(() => splash.classList.add('is-hidden'), 1650);
}

function preview() {
  const name = appName.value.trim() || 'Your app';
  document.querySelector('#preview-name').textContent = name;
  document.querySelector('#identity-name').textContent = name;
  let domain = 'your-website.com';
  try { domain = new URL(website.value).hostname || domain; } catch {}
  document.querySelector('#preview-domain').textContent = domain;
  document.querySelector('#identity-domain').textContent = domain;
  const value = iconUrl?.value.trim() || '';
  setPreviewIcon(value);
}
appName?.addEventListener('input', preview);
website?.addEventListener('input', () => {
  preview();
  clearTimeout(previewTimer);
  previewTimer = setTimeout(() => launchPreview(), 650);
});
iconUrl?.addEventListener('input', preview);
['preview', 'identity'].forEach(type => document.querySelector(`#${type}-icon`)?.addEventListener('error', event => {
  event.currentTarget.hidden = true;
  document.querySelector(`#${type}-icon-fallback`).hidden = false;
}));
document.querySelector('#replay-preview')?.addEventListener('click', () => launchPreview());
document.querySelector('#reload-preview')?.addEventListener('click', () => launchPreview(true));
document.querySelector('#open-preview')?.addEventListener('click', event => {
  if (!normalizedPreviewUrl()) event.preventDefault();
});
if (form) {
  preview();
  launchPreview();
}

async function api(url, options = {}) {
  const response = await fetch(url, {credentials: 'same-origin', ...options});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed. Please try again.');
  return data;
}

function makeLink(text, href, external = false) {
  const link = document.createElement('a');
  link.textContent = text; link.href = href; link.className = 'small-button';
  if (external) { link.target = '_blank'; link.rel = 'noopener noreferrer'; }
  return link;
}

async function poll(row, attempts = 0) {
  const id = row.dataset.id;
  clearTimeout(timers.get(id));
  const status = row.querySelector('.build-status');
  const actions = row.querySelector('.build-actions');
  try {
    const result = await api(`?action=status&id=${encodeURIComponent(id)}`);
    actions.replaceChildren();
    if (result.run_url) actions.append(makeLink('View logs ↗', result.run_url, true));
    if (result.status === 'completed') {
      if (result.download_ready) {
        status.textContent = 'Ready · Unsigned IPA'; row.dataset.state = 'success';
        actions.append(makeLink('Download IPA ↓', `?action=download&id=${encodeURIComponent(id)}`));
      } else if (result.expired) {
        status.textContent = 'Download expired · Start a new build';
      } else if (result.conclusion === 'success' && attempts < 4) {
        status.textContent = 'Build passed · Waiting for download';
        timers.set(id, setTimeout(() => poll(row, attempts + 1), 8000));
      } else {
        status.textContent = result.conclusion === 'success' ? 'Build passed, but no IPA artifact was found. Check logs.' : `Build ${result.conclusion || 'finished'} · Check logs`;
        row.dataset.state = 'error';
      }
      return;
    }
    if (result.status === 'not_found') {
      status.textContent = 'No run found. Check your token and workflow setup, then start a new build.';
      row.dataset.state = 'error'; return;
    }
    status.textContent = result.status === 'in_progress' ? 'Building on macOS…' : 'Waiting for GitHub…';
    row.dataset.state = 'active';
    timers.set(id, setTimeout(() => poll(row), 8000));
  } catch (error) {
    status.textContent = error.message;
    actions.replaceChildren();
    const retry = document.createElement('button'); retry.className = 'small-button'; retry.textContent = 'Retry status';
    retry.addEventListener('click', () => poll(row)); actions.append(retry);
  }
}

form?.addEventListener('submit', async event => {
  event.preventDefault();
  const button = document.querySelector('#build-button');
  const message = document.querySelector('#form-message');
  button.disabled = true; button.textContent = 'Sending to GitHub…'; message.hidden = true;
  try {
    const body = new FormData(form); body.set('csrf', csrf);
    const result = await api('?action=build', {method: 'POST', body});
    const row = document.createElement('article'); row.className = 'build-row'; row.dataset.id = result.job.request_id;
    const details = document.createElement('div'); const title = document.createElement('strong'); title.textContent = result.job.app_name;
    const status = document.createElement('p'); status.className = 'build-status'; status.textContent = 'Waiting for GitHub…';
    const actions = document.createElement('div'); actions.className = 'build-actions';
    details.append(title, status); row.append(details, actions); list.prepend(row);
    document.querySelector('#empty-builds').hidden = true;
    if (result.warning) { message.textContent = result.warning; message.hidden = false; }
    poll(row);
    row.scrollIntoView({behavior: 'smooth', block: 'nearest'});
  } catch (error) { message.textContent = error.message; message.hidden = false; }
  finally { button.disabled = false; button.textContent = 'Build my IPA →'; }
});
document.querySelectorAll('.build-row').forEach(row => poll(row));
