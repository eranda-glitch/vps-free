<?php
return [
    // Copy this file to config.local.php. Never commit that file to GitHub.
    // Generate a hash: php -r "echo password_hash('your-long-password', PASSWORD_DEFAULT), PHP_EOL;"
    'password_hash' => '',
    // Fine-grained token, limited to the build repository, Actions: read and write.
    'github_token' => '',
    'github_owner' => 'eranda-glitch',
    'github_repo' => 'vps-free',
    'github_ref' => 'main',
    'github_workflow' => 'build-website-ipa.yml',
    // Set true on HTTPS hosting. Leave false for http://localhost on Windows.
    'secure_cookie' => false,
];
