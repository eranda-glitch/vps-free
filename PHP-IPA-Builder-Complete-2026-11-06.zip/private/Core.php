<?php
declare(strict_types=1);

namespace IpaBuilder;

use RuntimeException;
use InvalidArgumentException;
use ZipArchive;

function validateInput(array $input): array
{
    $name = trim((string)($input['app_name'] ?? ''));
    $url = trim((string)($input['website_url'] ?? ''));
    $iconUrl = trim((string)($input['icon_url'] ?? ''));
    $bundle = trim((string)($input['bundle_id'] ?? ''));
    if (!preg_match('/\A[A-Za-z0-9][A-Za-z0-9 ._-]{0,29}\z/', $name)) {
        throw new InvalidArgumentException('Use 1–30 letters, numbers, spaces, dots, underscores or hyphens for the app name.');
    }
    $parts = parse_url($url);
    if (strlen($url) > 2048 || !filter_var($url, FILTER_VALIDATE_URL) || !$parts
        || ($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass'])
        || preg_match('/[\x00-\x20\x7f]/', $url)) {
        throw new InvalidArgumentException('Enter a valid HTTPS website URL without a username or password.');
    }
    $host = $parts['host'] ?? '';
    if (!str_contains($host, '.') || preg_match('/(?:\A|\.)(?:localhost|local|internal)\z/i', $host)
        || (filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {
        throw new InvalidArgumentException('Use a public website address, not a local network address.');
    }
    if (strlen($bundle) > 150 || !preg_match('/\A[A-Za-z][A-Za-z0-9-]*(?:\.[A-Za-z][A-Za-z0-9-]*)+\z/', $bundle)) {
        throw new InvalidArgumentException('Use a bundle ID such as com.yourname.myapp. Start each part with a letter.');
    }
    if ($iconUrl !== '') {
        $iconParts = parse_url($iconUrl);
        if (strlen($iconUrl) > 2048 || !filter_var($iconUrl, FILTER_VALIDATE_URL) || !$iconParts
            || ($iconParts['scheme'] ?? '') !== 'https' || isset($iconParts['user']) || isset($iconParts['pass'])
            || preg_match('/[\x00-\x20\x7f]/', $iconUrl)) {
            throw new InvalidArgumentException('Enter a valid HTTPS app icon URL.');
        }
        $iconHost = $iconParts['host'] ?? '';
        if (!str_contains($iconHost, '.') || preg_match('/(?:\A|\.)(?:localhost|local|internal)\z/i', $iconHost)
            || (filter_var($iconHost, FILTER_VALIDATE_IP) && !filter_var($iconHost, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {
            throw new InvalidArgumentException('Use a public app icon address, not a local network address.');
        }
    }
    return ['app_name' => $name, 'website_url' => $url, 'icon_url' => $iconUrl, 'bundle_id' => $bundle];
}

final class GitHub
{
    private string $base;
    private $transport;

    public function __construct(private array $config, ?callable $transport = null)
    {
        foreach (['github_owner', 'github_repo'] as $key) {
            if (!preg_match('/\A[A-Za-z0-9_.-]+\z/', $config[$key] ?? '')) {
                throw new RuntimeException('Check the GitHub repository configuration.');
            }
        }
        $this->base = '/repos/' . rawurlencode($config['github_owner']) . '/' . rawurlencode($config['github_repo']);
        $this->transport = $transport;
    }

    public function request(string $method, string $path, ?array $body = null): array
    {
        if ($this->transport) {
            $response = ($this->transport)($method, $this->base . $path, $body);
        } else {
            $headers = [];
            $curl = curl_init('https://api.github.com' . $this->base . $path);
            curl_setopt_array($curl, [
                CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 25,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_HTTPHEADER => [
                    'Accept: application/vnd.github+json', 'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->config['github_token'],
                    'X-GitHub-Api-Version: 2026-03-10', 'User-Agent: PHP-IPA-Builder',
                ],
                CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$headers): int {
                    if (str_contains($line, ':')) {
                        [$key, $value] = explode(':', $line, 2);
                        $headers[strtolower(trim($key))] = trim($value);
                    }
                    return strlen($line);
                },
            ]);
            if ($body !== null) curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($body, JSON_THROW_ON_ERROR));
            $raw = curl_exec($curl);
            $status = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            $errno = curl_errno($curl);
            curl_close($curl);
            if ($raw === false) {
                throw new RuntimeException($errno === 60
                    ? 'PHP could not verify GitHub’s TLS certificate. Configure curl.cainfo with a current CA bundle.'
                    : 'Could not reach GitHub. Check the server connection and try again.');
            }
            $response = ['status' => $status, 'data' => json_decode($raw, true) ?? [], 'headers' => $headers];
        }
        if ($response['status'] >= 400) {
            $message = match ($response['status']) {
                401 => 'GitHub rejected the token. Check that it is correct and has not expired.',
                403, 429 => 'GitHub denied the request or its rate limit was reached. Check Actions permissions and retry later.',
                404 => 'GitHub could not find the repository, workflow or artifact. Check the configuration and token access.',
                410 => 'This build artifact has expired. Start a new build.',
                422 => 'GitHub rejected the workflow inputs. Install the supplied workflow on the default branch.',
                default => 'GitHub returned an error (HTTP ' . (int)$response['status'] . '). Try again later.',
            };
            throw new RuntimeException($message);
        }
        return $response;
    }

    public function dispatch(array $input, string $requestId): ?int
    {
        $result = $this->request('POST', '/actions/workflows/' . rawurlencode($this->config['github_workflow']) . '/dispatches', [
            'ref' => $this->config['github_ref'], 'inputs' => $input + ['request_id' => $requestId],
        ]);
        return isset($result['data']['workflow_run_id']) ? (int)$result['data']['workflow_run_id'] : null;
    }

    public function run(array $job): ?array
    {
        $run = null;
        if (!empty($job['run_id'])) {
            $run = $this->request('GET', '/actions/runs/' . (int)$job['run_id'])['data'];
        } else {
            // Compatibility with GitHub versions that return 204 from dispatch.
            for ($page = 1; $page <= 3; $page++) {
                $query = http_build_query(['event' => 'workflow_dispatch', 'branch' => $this->config['github_ref'], 'per_page' => 100, 'page' => $page]);
                $runs = $this->request('GET', '/actions/workflows/' . rawurlencode($this->config['github_workflow']) . '/runs?' . $query)['data']['workflow_runs'] ?? [];
                foreach ($runs as $candidate) {
                    if (($candidate['display_title'] ?? '') === 'Web IPA - ' . $job['request_id']) {
                        $run = $candidate;
                        break 2;
                    }
                }
                if (count($runs) < 100) break;
            }
        }
        if ($run && (($run['display_title'] ?? '') !== 'Web IPA - ' . $job['request_id']
            || ($run['head_branch'] ?? '') !== $this->config['github_ref']
            || ($run['event'] ?? '') !== 'workflow_dispatch')) {
            throw new RuntimeException('The returned build did not match this request.');
        }
        return $run;
    }

    public function artifact(int $runId): ?array
    {
        $artifacts = $this->request('GET', '/actions/runs/' . $runId . '/artifacts?per_page=100')['data']['artifacts'] ?? [];
        foreach ($artifacts as $artifact) {
            if (($artifact['name'] ?? '') === 'website-ipa') return $artifact;
        }
        return null;
    }

    public function runLink(int $runId): string
    {
        return 'https://github.com/' . $this->config['github_owner'] . '/' . $this->config['github_repo'] . '/actions/runs/' . $runId;
    }

    public function downloadIpa(int $artifactId): string
    {
        $response = $this->request('GET', '/actions/artifacts/' . $artifactId . '/zip');
        $location = $response['headers']['location'] ?? '';
        $parts = parse_url($location);
        $host = strtolower($parts['host'] ?? '');
        if ($response['status'] !== 302 || ($parts['scheme'] ?? '') !== 'https'
            || isset($parts['user']) || isset($parts['pass'])
            || !(str_ends_with($host, '.blob.core.windows.net') || str_ends_with($host, '.githubusercontent.com') || str_ends_with($host, '.github.com'))) {
            throw new RuntimeException('GitHub returned an unexpected artifact download address.');
        }
        $zipPath = tempnam(sys_get_temp_dir(), 'ipa-zip-');
        $ipaPath = null;
        try {
            $file = fopen($zipPath, 'wb');
            $bytes = 0;
            $curl = curl_init($location);
            // The GitHub token is deliberately not sent to the artifact storage host.
            curl_setopt_array($curl, [CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 60,
                CURLOPT_WRITEFUNCTION => static function ($ch, string $data) use ($file, &$bytes): int {
                    $bytes += strlen($data);
                    if ($bytes > 25 * 1024 * 1024) return 0;
                    return fwrite($file, $data);
                }]);
            $ok = curl_exec($curl);
            $status = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);
            fclose($file);
            if ($ok === false || $status !== 200) throw new RuntimeException('Artifact download failed or exceeded 25 MB. Try again.');
            $ipaPath = extractIpa($zipPath);
            return $ipaPath;
        } finally {
            if (is_file($zipPath)) unlink($zipPath);
        }
    }
}

function extractIpa(string $zipPath): string
{
    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) throw new RuntimeException('The downloaded artifact is not a valid ZIP.');
    $output = null;
    try {
        $entry = $zip->statName('WebApp-unsigned.ipa');
        if (!$entry || $entry['size'] < 1 || $entry['size'] > 25 * 1024 * 1024) {
            throw new RuntimeException('The artifact does not contain the expected IPA.');
        }
        $stream = $zip->getStream('WebApp-unsigned.ipa');
        if (!$stream) throw new RuntimeException('The IPA could not be read.');
        $output = tempnam(sys_get_temp_dir(), 'ipa-file-');
        $destination = fopen($output, 'wb');
        $copied = stream_copy_to_stream($stream, $destination, 25 * 1024 * 1024 + 1);
        fclose($stream);
        fclose($destination);
        if ($copied !== $entry['size']) throw new RuntimeException('The IPA download is incomplete.');
        return $output;
    } catch (\Throwable $error) {
        if ($output && is_file($output)) unlink($output);
        throw $error;
    } finally {
        $zip->close();
    }
}
