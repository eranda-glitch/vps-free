<?php
// Router for PHP's development server, which does not support Apache .htaccess.
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/');
if ($path === '/' || $path === '/index.php') { require __DIR__ . '/index.php'; return true; }
if (preg_match('~\A/assets/(?:style\.css|preview\.css|app\.js)\z~', $path)) return false;
http_response_code(404);
echo 'Not found';
return true;
