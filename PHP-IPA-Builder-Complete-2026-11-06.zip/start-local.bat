@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

if exist "C:\xampp\php\php.exe" (
  echo Starting IPA Studio at http://127.0.0.1:8088/
  "C:\xampp\php\php.exe" -S 127.0.0.1:8088 -t "%~dp0." "%~dp0router.php"
) else (
  set "PHP_EXE="
  for /f "delims=" %%I in ('where php 2^>nul') do if not defined PHP_EXE set "PHP_EXE=%%I"
  if not defined PHP_EXE (
    echo ERROR: PHP was not found. Install PHP or XAMPP, then run this file again.
    pause
    exit /b 1
  )

  for %%I in ("!PHP_EXE!") do set "PHP_DIR=%%~dpI"
  if not exist "!PHP_DIR!ext\php_curl.dll" (
    echo ERROR: PHP cURL extension was not found in "!PHP_DIR!ext".
    pause
    exit /b 1
  )
  if not exist "!PHP_DIR!ext\php_zip.dll" (
    echo ERROR: PHP ZIP extension was not found in "!PHP_DIR!ext".
    pause
    exit /b 1
  )

  echo Starting IPA Studio at http://127.0.0.1:8088/
  "!PHP_EXE!" -d "extension_dir=!PHP_DIR!ext" -d extension=curl -d extension=zip -S 127.0.0.1:8088 -t "%~dp0." "%~dp0router.php"
)

if errorlevel 1 (
  echo.
  echo IPA Studio could not start. Review the error above.
  pause
  exit /b 1
)
