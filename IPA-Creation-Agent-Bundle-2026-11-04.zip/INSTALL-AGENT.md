# IPA Wrapper Builder agent

## Install once

Copy the `ipa-wrapper-builder` folder into:

```text
C:\Users\YOUR-NAME\.codex\skills\ipa-wrapper-builder
```

Restart Codex if the skill does not appear immediately.

## Use any time

Mention `$ipa-wrapper-builder` in a request. Examples:

```text
Use $ipa-wrapper-builder to create an IPA for https://example.com named My App with bundle ID com.example.myapp.
```

```text
Use $ipa-wrapper-builder to update F:\ipa creator\php-ipa-builder and make a clean deployment ZIP.
```

```text
Use $ipa-wrapper-builder to diagnose why my unsigned IPA will not install.
```

## Included deployment package

`IPA-Studio-Deploy-2026-11-04.zip` contains the clean PHP IPA Studio files and GitHub Actions workflow. It excludes `private/config.local.php`, GitHub tokens, password hashes, PHP sessions, Git metadata, previous archives, and IPA files.

Read `SETUP.md` inside that ZIP for GitHub workflow, token, local Windows, Livehost/cPanel, build, download, and troubleshooting instructions.

The builder creates unsigned WKWebView website-wrapper IPAs. The website must be available over public HTTPS. Signing and provisioning are separate.
