param(
  [Parameter(Mandatory=$true)][string]$ProjectRoot,
  [string]$OutputPath
)

$root = [IO.Path]::GetFullPath($ProjectRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw "Builder folder not found: $root" }
foreach ($required in @('index.php','SETUP.md','workflow\build-website-ipa.yml','private\config.example.php')) {
  if (-not (Test-Path -LiteralPath (Join-Path $root $required) -PathType Leaf)) { throw "Not a recognized IPA builder; missing $required" }
}

if (-not $OutputPath) {
  $OutputPath = Join-Path (Split-Path $root -Parent) ("IPA-Studio-Deploy-{0}.zip" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
}
$output = [IO.Path]::GetFullPath($OutputPath)
if ($output.StartsWith($root + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Write the ZIP outside the project folder.' }
if (Test-Path -LiteralPath $output) { throw "Output already exists: $output" }

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stream = [IO.File]::Open($output,[IO.FileMode]::CreateNew)
try {
  $archive = [IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
  try {
    $files = Get-ChildItem -LiteralPath $root -Recurse -File
    foreach ($file in $files) {
      $relative = $file.FullName.Substring($root.Length + 1).Replace('\','/')
      if ($relative -ieq 'private/config.local.php') { continue }
      if ($relative -like 'private/sessions/*') { continue }
      if ($relative -like '.git/*') { continue }
      if ($relative -match '(?i)\.(zip|tar|gz|ipa)$') { continue }
      [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$relative,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
  } finally { $archive.Dispose() }
} finally { $stream.Dispose() }

$check = [IO.Compression.ZipFile]::OpenRead($output)
try {
  $names = @($check.Entries | ForEach-Object FullName)
  foreach ($required in @('index.php','SETUP.md','workflow/build-website-ipa.yml','private/config.example.php')) {
    if ($names -notcontains $required) { throw "Package verification failed; missing $required" }
  }
  if ($names -contains 'private/config.local.php' -or $names -match '^private/sessions/') { throw 'Package verification failed; private data was included.' }
} finally { $check.Dispose() }

Get-Item -LiteralPath $output | Select-Object FullName,Length,LastWriteTime
