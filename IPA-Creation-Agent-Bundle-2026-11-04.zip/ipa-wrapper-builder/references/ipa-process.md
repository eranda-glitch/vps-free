# Senumy website-to-IPA process

## Components

- `index.php`, `assets/`, `router.php`: operator UI and local server routing.
- `private/Core.php`: authentication, GitHub Actions dispatch, status polling, artifact retrieval, and validation.
- `private/config.example.php`: safe configuration template.
- `private/config.local.php`: real token and password hash; never share or package.
- `private/template/`: readable Objective-C wrapper, plist, build script, and icons.
- `tools/make-workflow.php`: embeds the readable template into the self-contained GitHub Actions workflow.
- `workflow/build-website-ipa.yml`: the only builder file that normally needs uploading to `.github/workflows/`.
- `tests/run.php`: PHP behavior and security checks.

## First-time setup

1. Upload `workflow/build-website-ipa.yml` to `.github/workflows/build-website-ipa.yml` on the repository's default branch.
2. Enable GitHub Actions and confirm the **Build Website IPA** workflow appears.
3. Create a fine-grained GitHub token restricted to that repository with Actions read/write permission.
4. Copy `private/config.example.php` to `private/config.local.php` and set the token, repository, branch, workflow filename, and a PHP password hash.
5. For local Windows use, run `start-local.bat` and open `http://127.0.0.1:8088/`.
6. For hosted use, upload the clean deployment ZIP, enable PHP 8.2+ with cURL, ZIP, OpenSSL, and sessions, protect `private/`, and use HTTPS.

## Build request

1. Sign in to IPA Studio.
2. Enter the public HTTPS website URL, app name, unique bundle ID, and optional public icon URL.
3. Start the build. The PHP application dispatches GitHub Actions with a unique request ID.
4. GitHub's macOS runner compiles the Objective-C WKWebView wrapper for arm64 iOS, builds the `.app`, and packages an unsigned `.ipa`.
5. IPA Studio polls the run and downloads only the expected IPA artifact.
6. Sign and provision the IPA with the user's chosen signing method, then test it on a real iPhone.

## Important boundaries

- The website remains hosted online; the wrapper loads its URL at runtime.
- Camera, downloads, authentication popups, deep links, and external-app integrations may need native changes.
- The output is unsigned by design. A correct build can still fail to install until it is signed for the target device.
- Changing the bundle ID creates a distinct app identity; it does not migrate data from an older bundle ID.
- Do not disable TLS verification to work around PHP cURL certificate errors. Configure a current CA bundle instead.

## Troubleshooting map

- `401`: token is invalid or expired.
- `403`: token permissions, repository policies, or rate limits.
- `404`: owner, repository, workflow filename, or token repository access.
- `422` or no matching run: workflow not on the default branch, wrong branch, or invalid inputs.
- Long queue: GitHub Actions runner availability, billing, or macOS minutes.
- Build failure: inspect the workflow log and template generation; do not expose secrets in copied logs.
- IPA will not install: sign and provision it, then check bundle ID and device compatibility.
