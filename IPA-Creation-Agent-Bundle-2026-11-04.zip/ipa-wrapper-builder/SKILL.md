---
name: ipa-wrapper-builder
description: Create, maintain, validate, and package the Senumy PHP/GitHub Actions website-to-IPA builder. Use for URL-wrapper IPA builds, IPA Studio deployment ZIPs, workflow updates, bundle IDs, app icons, or diagnosing unsigned IPA creation. Do not use for converting arbitrary native projects or making a website work fully offline.
---

# IPA Wrapper Builder

Use the user's specified builder path. If none is given and the existing Senumy workspace is in scope, inspect `F:\ipa creator\php-ipa-builder` before assuming it is the target.

This workflow creates an **unsigned iPhone WKWebView wrapper IPA** around a public HTTPS website. It does not convert PHP, APK, Windows, or arbitrary project files into native iOS code. Signing, provisioning, and installation are separate steps.

## Route the request

- For building an IPA from a URL, collect or infer the public HTTPS URL, app display name, bundle ID, and optional public HTTPS icon URL. Do not invent a production bundle ID when the user has not supplied one.
- For changing the builder or iOS wrapper, inspect the project and read [references/ipa-process.md](references/ipa-process.md) before editing.
- For a deployment ZIP, use `scripts/package-ipa-builder.ps1`; never include secrets, session files, Git data, prior archives, or temporary artifacts.
- For a fully offline IPA, explain that it is a different architecture. Do not present this URL-wrapper workflow as offline-capable.

## Required validation

- Website and icon URLs must use public `https://` addresses without embedded credentials.
- App name: 1–30 characters, starting with a letter or number; allow letters, numbers, spaces, period, underscore, and hyphen.
- Bundle ID: dot-separated reverse-domain form such as `com.senumy.myapp`; each component starts with a letter and contains only letters, numbers, or hyphens.
- Treat `private/config.local.php`, GitHub tokens, password hashes, and `private/sessions/` as secrets. Never print, package, commit, or upload them.
- Preserve unrelated user changes. Never overwrite a working workflow or configuration without inspecting it first.

## Change and verify

The readable native sources in `private/template/` are the source of truth. After changing them, regenerate `workflow/build-website-ipa.yml` with:

```powershell
php tools/make-workflow.php
```

Run proportionate checks before packaging:

```powershell
php tests/run.php
php -l index.php
php -l router.php
php -l private/Core.php
```

When the workflow changes, confirm the generated YAML contains the intended source and does not contain credentials. GitHub uploads, commits, workflow dispatches, and signing require the user's explicit authorization and appropriate credentials.

## Deliver

Lead with the produced IPA or deployment ZIP, then state:

- whether it is unsigned;
- the embedded URL, app name, and bundle ID when relevant;
- which GitHub workflow file must be installed;
- that real-device installation requires signing/provisioning;
- any validation that could not be performed.

For first-time setup or troubleshooting, read [references/ipa-process.md](references/ipa-process.md).
